from project.task import Task


class Section:
    def __init__(self, name):
        self.name = name
        self.tasks = []

    def add_task(self, new_task: Task):
        if new_task not in self.tasks:
            self.tasks.append(new_task)
            return f"Task {Task.details(new_task)} is added to the section"
        return f"Task is already in the section {self.name}"

    def complete_task(self, searched_task: str):
        task = [taska for taska in self.tasks if taska.name == searched_task]
        if task:
            current_task = task[0]
            current_task.completed = True
            return f"Completed task {searched_task}"
        return f"Could not find task with the name {searched_task}"

    def clean_section(self):
        names = [task for task in self.tasks if task.completed]
        for i in names:
            self.tasks.remove(i)
        if names:
            return f"Cleared {len(names)} tasks."
        return "Cleared 0 tasks."

    def view_section(self):
        result = ""
        result += f"Section {self.name}:\n"
        for tsk in self.tasks:
            result += f"{tsk.details()}\n"
        return result
