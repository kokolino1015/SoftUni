from project.motorcycle import Hero

class Elf(Hero):
    pass