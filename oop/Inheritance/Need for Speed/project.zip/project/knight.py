from project.motorcycle import Hero

class Knight(Hero):
    pass