class Product:
    def __init__(self, name, quantity):
        self.name = str(name)
        self.quantity = int(quantity)

    def decrease(self, quantity):
        if self.quantity - quantity >= 0:
            self.quantity -= quantity

    def increase(self, quantity):
        self.quantity += quantity
