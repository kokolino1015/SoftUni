from abc import ABC, abstractmethod
from project.food import Food


class Animal(ABC):
    def __init__(self, name, weight, food_eaten=0):
        self.name = name
        self.weight = weight
        self.food_eaten = food_eaten

    def make_sound(self):
        return self._SOUND

    @property
    @abstractmethod
    def _SOUND(self) -> str:
        ...

    @property
    @abstractmethod
    def _VALID_FOOD_TYPES(self):
        ...

    @abstractmethod
    def __repr__(self) -> str:
        ...

    def feed(self, food: Food):
        if not isinstance(food, Food) or not isinstance(food, self._VALID_FOOD_TYPES):
            return f"{self.__class__.__name__} does not eat {food.__class__.__name__}!"

        self.food_eaten += food.quantity
        self.weight += food.quantity * self._WEIGHT_INCREASE_FACTOR

    @property
    @abstractmethod
    def _WEIGHT_INCREASE_FACTOR(self) -> float:
        ...

    @abstractmethod
    def __repr__(self):
        ...


class Bird(Animal):
    def __init__(self, name, weight, wing_size, food_eaten=0):
        super().__init__(name, weight, food_eaten)
        self.wing_size = wing_size

    def __repr__(self):
        return f"{self.__class__.__name__} [{self.name}, {self.wing_size}, {self.weight}, {self.food_eaten}]"


class Mammal(Animal):
    living_region: str

    def __init__(self, name: str, weight: float, living_region: str, food_eaten: int = 0) -> None:
        super().__init__(name, weight, food_eaten=food_eaten)
        self.living_region = living_region

    def __repr__(self) -> str:
        return f"{self.__class__.__name__} [{self.name}, {self.weight}, {self.living_region}, {self.food_eaten}]"
