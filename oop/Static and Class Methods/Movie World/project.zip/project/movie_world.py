from project.dvd import DVD
from project.customer import Customer


class MovieWorld:
    def __init__(self, name):
        self.name = name
        self.dvds = []
        self.customers = []

    @staticmethod
    def dvd_capacity():
        return 15

    @staticmethod
    def customer_capacity():
        return 10

    def add_customer(self, customer):
        if not len(self.customers) == 10:
            self.customers.append(customer)

    def add_dvd(self, dvd):
        if not len(self.dvds) == 15:
            self.dvds.append(dvd)

    def rent_dvd(self, customer_id: int, dvd_id: int):
        customer = [customer for customer in self.customers if customer.id == customer_id]
        dvd = [dvd for dvd in self.dvds if dvd.id == dvd_id]
        dvd = dvd[0]
        customer = customer[0]
        if dvd in customer.rented_dvds:
            return f"{customer.name} has already rented {dvd.name}"
        if dvd.is_rented:
            return "DVD is already rented"
        if customer.age < dvd.age_restriction:
            return f"{customer.name} should be at least {dvd.age_restriction} to rent this movie"
        customer.rented_dvds.append(dvd)
        dvd.is_rented = True
        return f"{customer.name} has successfully rented {dvd.name}"

    def return_dvd(self, customer_id: int, dvd_id: int):
        customer = [customer for customer in self.customers if customer.id == customer_id]
        dvd = [dvd for dvd in self.dvds if dvd.id == dvd_id]
        dvd = dvd[0]
        customer = customer[0]
        if dvd in customer.rented_dvds:
            dvd.is_rented = False
            customer.rented_dvds.remove(dvd)
            return f"{customer.name} has successfully returned {dvd.name}"
        return f"{customer.name} does not have that DVD"

    def __repr__(self):
        result = ""
        for i in range(len(self.customers)):
            result += f"{self.customers[i]}\n"
        for i in range(len(self.dvds)):
            result += f"{self.dvds[i]}\n"
        return result
