from project.hero import Hero

import unittest


class TestHero(unittest.TestCase):
    def setUp(self):
        self.hero = Hero("Test", 18, 100, 100)

    def test_init(self):
        self.assertEqual('Test', self.hero.username)
        self.assertEqual(18, self.hero.level)
        self.assertEqual(100, self.hero.health)
        self.assertEqual(100, self.hero.damage)

    def test_battle_error_case_battle_yourself(self):
        enemy = Hero('Test', 18, 100, 100)
        with self.assertRaises(Exception) as ex:
            self.hero.battle(enemy)
        self.assertEqual('You cannot fight yourself', str(ex.exception))

    def test_battle_error_case_your_health_is_lower(self):
        self.hero.health = 0
        enemy = Hero('Tests', 18, 100, 100)
        with self.assertRaises(Exception) as ex:
            self.hero.battle(enemy)
        self.assertEqual("Your health is lower than or equal to 0. You need to rest", str(ex.exception))

    def test_battle_case_enemy_health_is_lower(self):
        enemy_hero = Hero('Tests', 18, 0, 100)
        with self.assertRaises(Exception) as ex:
            self.hero.battle(enemy_hero)
        self.assertEqual(f"You cannot fight {enemy_hero.username}. He needs to rest", str(ex.exception))

    def test_battle_case_draw(self):
        enemy_hero = Hero('Tests', 18, 100, 100)
        self.assertEqual('Draw', self.hero.battle(enemy_hero))

    def test_battle_case_win(self):
        enemy_hero = Hero('Tests', 1, 10, 10)
        self.assertEqual('You win', self.hero.battle(enemy_hero))
        self.assertEqual(self.hero.level, 19)
        self.assertEqual(self.hero.damage, 105)
        self.assertEqual(self.hero.health, 95)

    def test_battle_case_lose(self):
        self.hero.health = 5
        self.hero.level = 1
        self.hero.damage = 1
        enemy_hero = Hero('Tests', 100, 100, 100)
        self.assertEqual(self.hero.battle(enemy_hero), 'You lose')
        self.assertEqual(enemy_hero.health, 104)
        self.assertEqual(enemy_hero.level, 101)
        self.assertEqual(enemy_hero.damage, 105)

    def test_str_function(self):
        result = f"Hero {self.hero.username}: {self.hero.level} lvl\nHealth: {self.hero.health}\nDamage: {self.hero.damage}\n"
        self.assertEqual(result, self.hero.__str__())

if __name__ == '__main__':
    unittest.main()
