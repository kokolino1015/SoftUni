from project.mammal import Mammal
import unittest


class TestMammal(unittest.TestCase):
    def test_init(self):
        mammal = Mammal('Fluffy', 'Cat', 'Meow')
        self.assertEqual(mammal.name, 'Fluffy')
        self.assertEqual(mammal.type, 'Cat')
        self.assertEqual(mammal.sound, 'Meow')
        self.assertEqual(mammal._Mammal__kingdom, "animals")

    def test_make_sound(self):
        mammal = Mammal('Fluffy', 'Cat', 'Meow')
        result = mammal.make_sound()
        self.assertEqual(result, "Fluffy makes Meow")

    def test_get_kingdom(self):
        mammal = Mammal('Fluffy', 'Cat', 'Meow')
        result = mammal.get_kingdom()
        self.assertEqual(result, 'animals')

    def test_info(self):
        mammal = Mammal('Fluffy', 'Cat', 'Meow')
        result = mammal.info()
        self.assertEqual(result, "Fluffy is of type Cat")


if __name__ == "__main__":
    unittest.main()
