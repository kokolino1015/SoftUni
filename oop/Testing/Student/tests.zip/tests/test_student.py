from project.student import Student
import unittest


class TestStudent(unittest.TestCase):
    def setUp(self):
        self.student = Student('Test', {'test': []})

    def test_init(self):
        self.assertEqual(self.student.name, 'Test')
        self.assertEqual(self.student.courses, {'test': []})

    def test_enroll_first_case(self):
        self.assertEqual(self.student.enroll('test', [1, 2, 3]), "Course already added. Notes have been updated.")
        self.assertEqual(self.student.courses['test'], [1, 2, 3])

    def test_enroll_second_case_version1(self):
        self.assertEqual(self.student.enroll('tests', [1, 2, 3], ''), "Course and course notes have been added.")
        self.assertEqual(self.student.courses['tests'], [1, 2, 3])

    def test_enroll_second_case_version2(self):
        self.assertEqual(self.student.enroll('tests', [1, 2, 3], 'Y'), "Course and course notes have been added.")
        self.assertEqual(self.student.courses['tests'], [1, 2, 3])

    def test_enroll_third_case(self):
        self.assertEqual(self.student.enroll('tests', [1, 2, 3], 't'), "Course has been added.")
        self.assertEqual(self.student.courses['tests'], [])

    def test_add_notes_first_case(self):
        self.assertEqual(self.student.add_notes('test', 'c'), "Notes have been updated")
        self.assertEqual(self.student.courses["test"], ['c'])

    def test_add_notes_second_case(self):
        with self.assertRaises(Exception) as ex:
            self.student.add_notes('tests', 'tasa')
        self.assertEqual("Cannot add notes. Course not found.", str(ex.exception))

    def test_leave_course_first_case(self):
        self.assertEqual(self.student.leave_course('test'),'Course has been removed')
        self.assertEqual(self.student.courses, {})

    def test_leave_course_second_case(self):
        with self.assertRaises(Exception) as ex:
            self.student.leave_course('tests')
        self.assertEqual('Cannot remove course. Course not found.', str(ex.exception))


if __name__ == '__main__':
    unittest.main()
