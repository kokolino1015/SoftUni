from project.vehicle import Vehicle
import unittest


class TestVehicle(unittest.TestCase):
    def setUp(self):
        self.vehicle = Vehicle(100, 100)

    def test_init(self):
        self.assertEqual(100, self.vehicle.fuel)
        self.assertEqual(100, self.vehicle.capacity)
        self.assertEqual(100, self.vehicle.horse_power)
        self.assertEqual(1.25, self.vehicle.fuel_consumption)

    def test_drive_exception_case(self):
        with self.assertRaises(Exception) as ex:
            self.vehicle.drive(100)
        self.assertEqual("Not enough fuel", str(ex.exception))

    def test_drive_correct_case(self):
        self.vehicle.drive(4)
        self.assertEqual(95, self.vehicle.fuel)

    def test_refuel_exception_case(self):
        with self.assertRaises(Exception) as ex:
            self.vehicle.refuel(1)
        self.assertEqual("Too much fuel", str(ex.exception))

    def test_refuel_correct_case(self):
        self.vehicle.refuel(0)
        self.assertEqual(self.vehicle.fuel, 100)

    def test_str(self):
        res = f"The vehicle has 100 " \
               f"horse power with 100 fuel left and 1.25 fuel consumption"
        self.assertEqual(res, self.vehicle.__str__())


if __name__ == '__main__':
    unittest.main()
